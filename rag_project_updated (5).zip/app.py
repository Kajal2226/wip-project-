from flask import Flask, request, jsonify
from agents.retrieval_agent import RetrievalAgent
from agents.generation_agent import GenerationAgent
from models.chatbot import Chatbot
from models.document import Document

import crewai  # Assuming Crew.ai provides a Python package

# Initialize Crew.ai
crewai.api_key = "YOUR_CREWAI_API_KEY"  # Replace with your actual API key

app = Flask(__name__)

# In-memory storage for simplicity (could be replaced by a database)
users = {}

@app.route('/create_chatbot', methods=['POST'])
def create_chatbot():
    user_id = request.json.get('user_id')
    bot_name = request.json.get('bot_name')
    config = request.json.get('config')
    new_bot = Chatbot(bot_name, config)
    users.setdefault(user_id, []).append(new_bot)
    return jsonify({"message": f"Chatbot '{bot_name}' created successfully!"})

@app.route('/upload_document', methods=['POST'])
def upload_document():
    user_id = request.json.get('user_id')
    bot_name = request.json.get('bot_name')
    doc_content = request.json.get('document_content')
    new_doc = Document(content=doc_content)
    for bot in users.get(user_id, []):
        if bot.name == bot_name:
            bot.add_document(new_doc)
    return jsonify({"message": "Document uploaded successfully!"})

@app.route('/chat', methods=['POST'])
def chat():
    user_id = request.json.get('user_id')
    bot_name = request.json.get('bot_name')
    query = request.json.get('query')
    
    bot = next((bot for bot in users.get(user_id, []) if bot.name == bot_name), None)
    if not bot:
        return jsonify({"error": "Chatbot not found!"}), 404

    response = bot.respond(query)
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
