import crewai  # Assuming Crew.ai provides generation functions

class GenerationAgent:
    def __init__(self, config):
        self.config = config

    def generate_response(self, query, context):
        # Crew.ai generation function with safety filters
        response = crewai.generate(query, context, filters=self.config.get('constitutional_filters'))
        return response
