class Chatbot:
    def __init__(self, name, config):
        self.name = name
        self.config = config
        self.documents = []
        self.retrieval_agent = RetrievalAgent(config)
        self.generation_agent = GenerationAgent(config)

    def add_document(self, document):
        self.documents.append(document)
        self.retrieval_agent.index_document(document)

    def respond(self, query):
        retrieved_docs = self.retrieval_agent.retrieve(query)
        response = self.generation_agent.generate_response(query, retrieved_docs)
        return response
