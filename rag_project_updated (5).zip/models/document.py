class Document:
    def __init__(self, content):
        self.content = content
