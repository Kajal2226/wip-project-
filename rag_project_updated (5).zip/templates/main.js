document.getElementById('createBotForm').onsubmit = async (e) => {
    e.preventDefault();
    const botName = document.getElementById('botName').value;
    await fetch('/create_chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: 'user1', bot_name: botName, config: {} })
    });
};

document.getElementById('uploadDocForm').onsubmit = async (e) => {
    e.preventDefault();
    const file = document.getElementById('document').files[0];
    const reader = new FileReader();
    reader.onload = async function() {
        await fetch('/upload_document', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: 'user1', bot_name: 'myBot', document_content: reader.result })
        });
    };
    reader.readAsText(file);
};

document.getElementById('sendMessage').onclick = async () => {
    const query = document.getElementById('userQuery').value;
    const response = await fetch('/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: 'user1', bot_name: 'myBot', query })
    });
    const data = await response.json();
    document.getElementById('responseArea').innerText = data.response;
};
